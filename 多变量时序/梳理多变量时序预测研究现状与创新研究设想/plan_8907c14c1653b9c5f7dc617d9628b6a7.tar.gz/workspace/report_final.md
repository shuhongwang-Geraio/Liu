# 多变量时序数据预测领域科研指导报告

## 1. 摘要与研究背景

### 1.1 研究摘要

多变量时序预测（Multivariate Time Series Forecasting, MTSF）是机器学习领域的核心问题之一，在能源调度、金融风控、交通管理、气象预报等关键领域具有广泛应用价值。本报告通过系统分析7篇核心论文（DLinear、PatchTST、SOFTS、ModernTCN、RATD、Stable Learning等），并扩展检索27篇以上重要文献，全面梳理了2021-2025年间该领域的技术演进脉络、主流方法、核心争议与关键技术瓶颈。在此基础上，本报告提出5个具有创新潜力的研究方向，包括自适应通道交互机制、因果时序预测、高效扩散模型、分布外泛化与非平稳性建模、SSM-Transformer混合架构，并为每个方向提供详细的技术路径、相关文献支持与实验验证思路，旨在为后续科研任务提供系统性指导。

|报告维度|覆盖范围|
|---|---|
|时间跨度|2021-2025年|
|核心论文|7篇深度解读|
|扩展文献|27+篇系统梳理|
|技术路线|Transformer/MLP/TCN/扩散模型/SSM/因果推断|
|创新方向|5个详细设想|
|发表会议|AAAI/ICLR/NeurIPS/CVPR/ICML|

### 1.2 领域重要性与研究背景

多变量时序数据在现代社会无处不在：电力系统中的负荷与发电量、金融市场中的多资产价格、交通网络中的流量与速度、医疗监测中的多生理指标等。这些数据不仅具有时间维度上的动态演化特性，还存在变量间复杂的相互依赖关系[1]。准确预测这些多变量时序数据对于资源优化配置、风险预警与决策支持具有重要价值。

近年来，深度学习技术的快速发展为多变量时序预测带来了革命性变化。从2021年Informer、Autoformer将Transformer架构引入时序领域，到2022年DLinear以简单线性模型挑战复杂架构的必要性，再到2023年PatchTST通过Patch策略重新证明Transformer有效性，直至2024-2025年基础模型（Foundation Models）的涌现，该领域经历了从"Transformer至上"到"架构多元化"的深刻变革[1][4]。

当前，多变量时序预测领域面临六大核心挑战：通道独立（CI）与通道相关（CD）策略的选择争议、深层非平稳性处理不足、超长序列建模效率瓶颈、扩散模型推理效率低下、变量间因果关系建模缺失、计算效率与精度的持续权衡。这些挑战既是技术瓶颈，也是创新机遇所在。

### 1.3 报告结构

本报告共分为七个章节：第一章介绍研究背景与报告概述；第二章系统梳理2021-2025年领域技术演进与主流方法；第三章深度解读7篇核心论文；第四章分析六大关键技术瓶颈；第五章提出5个创新研究设想；第六章给出研究路线图与优先级建议；第七章列出完整参考文献。

---

## 2. 领域综述：技术演进与主流方法

### 2.1 2021-2025年技术演进时间线

多变量时序预测领域在2021至2025年间经历了从"Transformer至上"到"反思Transformer"，再到"架构多元化与基础模型涌现"的剧烈演变[1][4]。这一演变过程不仅重塑了技术路线的格局，也深刻影响了研究社区对时序数据本质特性的认知。

|时间阶段|核心事件|代表性工作|影响|
|---|---|---|---|
|2021|Transformer时序化|Informer,Autoformer|开启Transformer主导时代|
|2022|线性模型挑战|DLinear,FEDformer|质疑复杂架构必要性|
|2023|Patch策略崛起|PatchTST,TSMixer|重新证明Transformer有效性|
|2024|架构多元化|iTransformer,SOFTS,ModernTCN,RATD|各技术路线百花齐放|
|2025|基础模型元年|Chronos-Bolt,Moirai 2.0,TimesFM|预训练与零样本泛化成为焦点|

2021年标志着Transformer架构正式进入时序预测领域的主流视野。Informer通过ProbSparse注意力机制将计算复杂度从O(L²)降至O(L log L)[1]，Autoformer则引入序列分解与自相关机制[5]。然而，2022年DLinear的发表彻底改变了这一格局——一个简单的单层线性网络竟在多个基准数据集上击败了所有复杂的Transformer变体，引发了领域内对"注意力机制必要性"的广泛讨论[1]。

2023年成为技术路线分野的关键年份。PatchTST通过Patch化设计和通道独立策略，重新证明了Transformer在时序领域的有效性[1]。2024年见证了技术路线的全面多元化：iTransformer实现了变量Token化的范式反转[4]，SOFTS提出了线性复杂度的星形拓扑变量交互[2]，ModernTCN通过大核卷积复兴了CNN在时序领域的地位[11]，RATD则将检索增强引入扩散模型开辟了概率预测新范式[9]。2025年被视为"时序基础模型元年"，Chronos-Bolt、Moirai 2.0、TimesFM等模型实现了大规模预训练与Zero-shot泛化[6][23]。

### 2.2 六大主流技术路线详细分析

#### 2.2.1 Transformer路线：从点级Token到变量级Token

Transformer在时序预测领域的演进经历了三个阶段：效率优化阶段（2021-2022）、Token设计反思阶段（2023）、变量建模范式转换阶段（2024-2025）[1][4]。

|模型|年份/会议|核心创新|复杂度|CI/CD|
|---|---|---|---|---|
|Informer|AAAI 2021|ProbSparse注意力|O(L log L)|CD|
|Autoformer|NeurIPS 2021|序列分解+自相关|O(L log L)|CD|
|FEDformer|ICML 2022|频域注意力|O(L)|CD|
|PatchTST|ICLR 2023|Patch+通道独立|O((L/S)²·N)|CI|
|iTransformer|ICLR 2024|变量Token化|O(N²)|CD|
|TimeXer|2024|外部变量整合|O(N²)|CD|

Informer通过ProbSparse注意力机制筛选出最重要的Query，将复杂度降至O(L log L)[1]。Autoformer引入序列级连接的自相关机制取代点级自注意力，并将时间序列分解为趋势项和季节项[5]。FEDformer将注意力计算转移到频域，利用傅里叶变换实现O(L)复杂度。

PatchTST的核心洞见在于：时序数据不应像NLP那样以单点为Token，而应以子序列（Patch）为基本单元[1]。通过将时间序列划分为固定长度的Patch作为输入单元，PatchTST既保留了局部语义信息，又将Token数量从L减少到约L/S，使注意力机制的计算复杂度呈平方级降低。

iTransformer实现了"倒置Transformer"的范式反转——将每个变量整体视为一个Token，利用注意力机制显式建模变量间相关性，而非时间步之间的依赖[4]。这一设计解决了传统Transformer在多变量维度上的建模缺陷。

#### 2.2.2 线性/MLP路线：从简单基准到高效交互

线性模型与MLP的崛起是2022年后时序预测领域最重要的趋势之一，其演进路径清晰地展示了"简单有效"到"简单且高效交互"的技术进步[1][2]。

|模型|年份/会议|核心创新|复杂度|CI/CD|
|---|---|---|---|---|
|DLinear|AAAI 2022|单层线性映射|O(T·N)|CI|
|TSMixer|2023|时间/特征交替混合|O(L)|混合|
|SOFTS|NeurIPS 2024|STAR星形拓扑|O(C·L)|间接CD|
|TimeMixer|2024|多尺度混合|O(L)|混合|

DLinear采用极其简单的架构——仅用单层线性网络将历史窗口直接映射到预测窗口[1]。在ETT、ECL、Traffic等多个数据集上，DLinear的性能竟优于所有复杂Transformer变体，为领域建立了极具竞争力的基线。TSMixer利用全MLP架构，通过时间混合和特征混合交替操作达到SOTA性能[1]。SOFTS提出的STAR模块将通道间交互的复杂度从O(C²)降低到O(C)，同时增强了对异常通道的鲁棒性[2]。

#### 2.2.3 卷积路线：从局部感受野到大核卷积

卷积神经网络在时序预测领域经历了从边缘化到复兴的过程，大核卷积的引入是这一复兴的关键技术突破[10][11]。

|模型|年份/会议|核心创新|核心技术|
|---|---|---|---|
|SCINet|NeurIPS 2022|样本卷积交互|多尺度分解|
|TimesNet|ICLR 2023|2D变化建模|1D→2D转换|
|ModernTCN|ICLR 2024|大核卷积|51×51~71×71核|

SCINet利用样本卷积与交互学习捕捉多尺度时间特征[10]。TimesNet将一维时序转化为二维张量进行变化建模，通过FFT分析序列的主要周期[1]。ModernTCN借鉴计算机视觉中ConvNeXt的大核卷积思想，采用51×51甚至71×71的超大卷积核显著扩大有效感受野（ERF）[11]。研究表明，在纯卷积结构中，ERF与卷积核大小成线性正相关，而与层数仅呈亚线性关系O(ks×√nl)。在五大主流任务上，ModernTCN均达到SOTA水平，相比TimesNet，MSE平均降低27.4%。

#### 2.2.4 扩散模型路线：从确定性预测到概率分布

扩散模型为时序预测引入了概率建模框架，能够输出完整的预测分布而非单一点预测[3][9]。

|模型|年份|核心创新|技术特点|
|---|---|---|---|
|TimeGrad|2021|自回归扩散|逐步预测|
|CSDI|NeurIPS 2021|条件分数扩散|补全与预测统一|
|TimeDiff|2023|非自回归扩散|缓解误差累积|
|RATD|NeurIPS 2024|检索增强扩散|语义引导去噪|

RATD是扩散模型路线的重要突破，其核心贡献在于将检索增强（RAG）技术引入时序扩散模型[9]。利用预训练编码器将历史序列转化为嵌入向量，在预构建的数据库中检索相似样本作为"参考序列"，通过参考调制注意力机制（RMA）将参考信息融入去噪过程。在罕见病预测等复杂任务中，MSE较iTransformer降低51%，较CSDI降低59%。

#### 2.2.5 基础模型路线：从单数据集到大规模预训练

2024年被视为"时序基础模型元年"，研究重点从单一数据集训练转向大规模预训练与Zero-shot泛化[6][23]。

|模型|机构|架构类型|核心特点|
|---|---|---|---|
|Chronos|Amazon|Encoder-Decoder|时序值量化为Token|
|Chronos-Bolt|Amazon|优化版|推理速度提升250倍|
|Moirai|Salesforce|掩码编码器|任意频率/变量数|
|Moirai 2.0|Salesforce|Decoder-only|体积缩小96%|
|TimesFM|Google|Decoder-only|合成+真实数据预训练|
|Lag-Llama|开源|LLaMA架构|概率预测|

Chronos将时序值量化为离散Token，利用语言模型架构（T5）进行预测[6]。Moirai基于掩码编码器架构，支持任意频率和变量数量的输入[23]。TimesFM通过在大规模合成数据与真实数据上进行预训练，实现了卓越的零样本泛化能力，在标准基准的零样本评测中与微调模型性能相当[23]。Time-LLM通过"重编程"技术将时序Patch映射为文本原型，利用自然语言Prompt引导LLM理解任务背景[12]。

#### 2.2.6 SSM/Mamba路线：线性复杂度的新范式

Mamba架构凭借其线性复杂度和长序列建模能力，正成为Transformer的有力竞争者[11]。

|模型|年份|核心创新|技术特点|
|---|---|---|---|
|TimeMachine|2024|四重Mamba|统一通道交互|
|MambaTS|2024|时序Mamba|变量依赖建模|
|Mamba4Cast|2025|Mamba-2基础模型|推理速度领先|
|LinOSS|ICLR 2025|线性振荡状态空间|性能达Mamba 2倍|

TimeMachine利用四重Mamba结构统一了时间和通道两个维度的信息交互。ICLR 2025发表的LinOSS在长序列任务上实现了Mamba两倍的性能[11]，标志着SSM架构在时序预测领域的进一步成熟。

### 2.3 核心争议分析

#### 2.3.1 CI vs CD策略之争

通道独立（Channel-Independence, CI）与通道相关（Channel-Dependence, CD）策略的选择是当前领域最核心的未解争议[1][13][15]。这一争议的本质在于：多变量时序数据中变量间的相关信息究竟是"信号"还是"噪声"？

CI策略（如DLinear、PatchTST）在ETT、ECL、Weather等多数基准上表现更优，其优势源于三个方面：避免跨通道过拟合、对分布漂移具有更强鲁棒性、允许预训练数据与下游任务数据的变量数量不一致[1]。然而，从物理意义上看，完全忽略变量间信息在多传感器同步采集、供应链协同预测等场景下显然不合理。iTransformer通过变量Token化显式建模跨变量相关性[4]，在某些数据集上取得了优于CI方法的结果。

|策略|代表方法|优势|劣势|适用场景|
|---|---|---|---|---|
|纯CI|DLinear,PatchTST|抗过拟合、分布漂移鲁棒|丢失变量间信息|变量相关性弱|
|纯CD|Crossformer,iTransformer|充分利用变量关系|O(C²)复杂度、易过拟合|小规模通道|
|星形折中|SOFTS|线性复杂度、鲁棒性好|存在信息瓶颈|大规模通道|
|自适应|Channel Clustering|动态平衡|设计复杂|通用场景|

SOFTS的星形拓扑代表了CI与CD之间的折中路线[2]。Channel Clustering（NeurIPS 2024）提出根据通道相似性进行聚类，在簇内采用CD策略、簇间采用CI策略[14]。LIFT学习"领先指标"来捕捉变量间的异步依赖关系[15]。

#### 2.3.2 Transformer有效性之争

"Transformer在时序预测中是否真正有效"这一争论历经三年演变，目前已形成较为清晰的共识[1]。

第一阶段（2021-2022）：Transformer主导。Informer、Autoformer、FEDformer等工作将Transformer架构引入时序预测，通过各种效率优化技术解决长序列建模问题。第二阶段（2022-2023）：线性模型挑战。DLinear的发表彻底颠覆了复杂架构优于简单模型的假设，在常用基准上单层线性网络的性能优于所有Transformer变体[1]。第三阶段（2023-2024）：Patch策略回应。PatchTST对线性模型的挑战作出了有力回应——此前Transformer失败的原因不在于注意力机制本身，而在于Token设计不当[1]。

当前共识包括：(1) 简单线性模型是有效的强基线，任何复杂设计都需要证明其超越线性映射的增益；(2) Transformer的有效性取决于输入表示设计，Patch策略是关键；(3) 不存在"最优架构"，各技术路线各有优势场景。

### 2.4 代表性成果汇总

#### 2.4.1 重要论文汇总（2021-2025）

|年份|会议|论文|核心贡献|技术路线|
|---|---|---|---|---|
|2021|AAAI|Informer|ProbSparse注意力|Transformer|
|2021|NeurIPS|Autoformer|序列分解+自相关|Transformer|
|2021|CVPR|StableNet|稳定学习框架|因果推断|
|2022|AAAI|DLinear|线性基准|线性模型|
|2022|ICML|FEDformer|频域注意力|Transformer|
|2022|NeurIPS|Non-stationary Trans.|去平稳注意力|Transformer|
|2022|NeurIPS|SCINet|样本卷积交互|CNN|
|2023|ICLR|PatchTST|Patch+通道独立|Transformer|
|2023|ICLR|TimesNet|2D变化建模|CNN|
|2024|ICLR|iTransformer|变量Token化|Transformer|
|2024|ICLR|ModernTCN|大核卷积|CNN|
|2024|ICLR|Time-LLM|LLM重编程|LLM|
|2024|NeurIPS|SOFTS|STAR星形拓扑|MLP|
|2024|NeurIPS|RATD|检索增强扩散|扩散模型|
|2024|NeurIPS|FAN|频域自适应归一化|归一化|
|2025|ICLR|LinOSS|线性振荡SSM|SSM|

#### 2.4.2 各数据集SOTA方法对比

|数据集|类型|最优方法|次优方法|备注|
|---|---|---|---|---|
|ETTh1/ETTm1|能源|iTransformer/PatchTST|TimesFM|基础模型Zero-shot接近|
|ETTh2/ETTm2|能源|PatchTST|TimeMixer|CI策略占优|
|Weather|气象|iTransformer|TimesFM|CD策略有效|
|Electricity|电力|iTransformer|SOFTS|高维数据|
|Traffic|交通|SOFTS|ModernTCN|超高维(862变量)|
|PEMS|交通|SOFTS|iTransformer|大规模通道场景|
|Exchange|金融|RATD|PatchTST|概率预测场景|

---

## 3. 核心论文深度解读

### 3.1 DLinear：线性基准的里程碑意义

DLinear是一篇具有里程碑意义的论文，它通过提出一个极其简单的线性模型，对当时主流的Transformer架构在时序预测任务中的有效性提出了根本性质疑[1]。

**核心方法**：DLinear采用简单的线性映射结构，直接将历史时间窗口映射到预测窗口。与复杂的Transformer模型不同，它不包含任何注意力机制或非线性变换层。数学表达为：

$$Y = W \cdot X + b$$

其中$X \in \mathbb{R}^{L \times C}$为历史窗口，$Y \in \mathbb{R}^{H \times C}$为预测结果，$W$为可学习的线性投影矩阵。

**技术贡献**：该论文的核心贡献在于为时序预测领域建立了一个极具竞争力的基线，迫使后续研究必须证明其复杂模块确实带来了超越线性映射的性能增益。在ETT、ECL、Traffic等多个数据集的长程预测任务中，DLinear的性能优于Informer、Autoformer、FEDformer等所有复杂Transformer变体[1]。

**局限性**：DLinear的主要局限体现在三个方面：当通道数非常大时表现明显下降；线性本质限制了其捕捉非线性模式的能力；完全采用通道独立策略丢失了变量间的相关信息。

### 3.2 PatchTST：Patch策略与Transformer有效性的回应

PatchTST是对DLinear挑战的有力回应，它通过创新的Patch设计和通道独立策略，重新证明了Transformer架构在时序预测任务中的有效性[1]。

**核心方法**：PatchTST的核心设计包含三个关键组件。第一，Patch策略将每个通道的单变量时间序列划分为若干个子序列级别的"补丁"作为Transformer的输入Token。第二，通道独立机制将多变量时间序列拆分为独立通道，所有通道共享同一个Transformer主干网络。第三，自监督掩码预训练方法将输入序列划分为非重叠补丁，随机选择一部分补丁进行掩码（通常比例约40%），通过MSE损失训练模型重建被掩码的内容。

Patch化后的Token数量计算为：

$$N_{tokens} = \left\lfloor \frac{L - P}{S} \right\rfloor + 1$$

其中$L$为历史窗口长度，$P$为Patch长度，$S$为步长。

**技术贡献**：PatchTST重新证明了Transformer在时序领域的有效性，其Patch设计将输入Token数量从L减少到约L/S，使注意力机制的计算和内存消耗呈平方级降低。在多个基准数据集上，PatchTST相比其他Transformer模型实现了约20%的MSE降幅，训练速度可提升多达22倍[1]。

**局限性**：PatchTST的通道独立策略虽然带来了诸多优势，但理论上损失了变量间的相关信息，在变量间存在强相关性的场景下可能无法充分利用多变量信息。

### 3.3 SOFTS：星形拓扑的高效变量交互

SOFTS提出了一种高效的基于MLP的多变量时序预测模型，其核心创新在于STAR（STar Aggregate-Redistribute）模块，该模块通过星形拓扑结构实现了线性复杂度的变量交互[2]。

**核心方法**：STAR模块的设计灵感来源于软件工程中的星形中心化系统。与Transformer的分布式交互结构（两两比较）不同，STAR采用中心化策略，通过一个"核心表示"（Core Representation）来聚合和交换所有通道的信息。核心表示的生成过程包括：

$$Core = \text{StochasticPooling}(\text{MLP}(H_1), \text{MLP}(H_2), ..., \text{MLP}(H_C))$$

$$H'_i = H_i + \text{MLP}(Core)$$

其中$H_i$表示第$i$个通道的表示。

**技术贡献**：STAR模块将通道间的直接交互替换为通过"核心"进行的间接交互，将计算复杂度从常见的O(C²)降低到O(C)的线性复杂度。这种中心化结构增强了对异常通道的鲁棒性：当某个通道出现异常时，STAR能通过核心表示利用正常通道的信息将其"拉回"正常聚类[2]。

**局限性**：星形拓扑本质上是CI与CD之间的折中方案，信息的聚合和分发仍然通过单一的核心表示进行，可能在捕捉复杂的两两变量关系时存在信息瓶颈。

### 3.4 ModernTCN：大核卷积的复兴

ModernTCN是一种纯卷积结构的时序分析模型，通过"现代化"传统TCN的设计，在保持卷积模型高效率的同时达到了与Transformer相当甚至更优的性能[11]。

**核心方法**：ModernTCN的核心设计包含三个关键组件。DWConv（深度卷积）负责学习时间信息，采用大尺寸卷积核（如51×51或71×71）来扩大感受野。ConvFFN1负责在每个变量内部学习特征表示。ConvFFN2负责捕捉跨变量依赖关系。

有效感受野（ERF）与卷积参数的关系为：

$$ERF \propto k_s \times \sqrt{n_l}$$

其中$k_s$为卷积核大小，$n_l$为网络层数。因此优先通过增大卷积核而非堆叠深层小核来获取更大ERF更为高效。

**技术贡献**：ModernTCN在长期预测、短期预测、插补、分类和异常检测五大主流任务上均达到了SOTA水平。在长期预测任务中，相比TimesNet，MSE平均降低了27.4%，MAE降低了15.3%[11]。

**局限性**：ModernTCN在内存使用量上略逊于某些极轻量级的MLP模型。在ILI等特定数据集上，模型在不同参数设置下表现出较高的方差。

### 3.5 RATD：检索增强扩散模型

RATD（Retrieval-Augmented Time series Diffusion model）将检索增强技术引入时序扩散模型，通过检索数据库中的相似样本为去噪过程提供语义引导[9]。

**核心方法**：RATD的架构由两个核心部分组成。嵌入式检索过程利用预训练的编码器将历史时间序列转化为嵌入向量，在预先构建的数据库中检索出k个最相关样本作为"参考序列"。参考引导的扩散模型在反向去噪过程中学习条件概率分布：

$$p(x_{t-1}|x_t, x^H, x^R) = \mathcal{N}(x_{t-1}; \mu_\theta(x_t, x^H, x^R, t), \sigma_t^2 I)$$

其中$x^H$为历史序列，$x^R$为检索到的参考序列。

**技术贡献**：RATD的主要贡献在于为缺乏语义信息的扩散去噪过程提供了明确的引导。在四个真实世界数据集上，RATD在MSE、MAE和CRPS指标上均优于现有时序扩散模型。在罕见病预测任务中，其MSE（0.206）显著低于iTransformer（0.423）和CSDI（0.499）[9]。

**局限性**：作为基于Transformer的扩散模型结构，当处理包含过多变量的时间序列时会消耗大量计算资源。训练过程中需要进行额外的检索预处理，增加约10小时的额外训练时间成本。

### 3.6 Stable Learning：因果推断视角

Stable Learning论文提出了StableNet模型，通过消除特征间的依赖关系来提高深度学习模型在分布偏移（Out-Of-Distribution, OOD）下的泛化能力。虽然原论文面向计算机视觉任务，但其核心思想对时序预测领域具有重要的潜在应用价值。

**核心方法**：StableNet的核心技术包含两个关键组件。基于随机傅里叶特征（RFF）的非线性特征去相关利用RFF将特征映射到高维空间：

$$h(x) = \sqrt{2} \cdot \cos(\omega x + \phi)$$

通过学习样本权重来最小化特征间的偏互协方差矩阵的Frobenius范数，从而实现特征间的独立性。全局样本权重学习机制采用"保存与重载"策略，通过迭代地保存和更新全局特征及权重。

**在时序预测的潜在应用**：StableNet的核心思想在时序预测领域具有三方面潜在应用价值：处理非平稳环境（概念漂移）、消除伪相关（虚假的统计相关性）、全局相关性感知（以较低计算成本捕捉长程时间跨度上的全局特征相关性）。

---

## 4. 关键技术瓶颈分析

基于对核心论文的系统分析和领域最新进展的扩展检索，本章识别出六大关键技术瓶颈。

### 4.1 自适应CI/CD策略缺失

**问题描述**：当前方法要么完全采用CI（如DLinear、PatchTST），要么采用固定的CD结构（如iTransformer），要么采用静态折中方案（如SOFTS）[1][2][4]。缺乏能够根据数据特性、变量相关强度、预测任务需求动态调整变量交互程度的自适应机制。

**现有尝试**：Channel Clustering（NeurIPS 2024）提出根据通道相似性进行聚类[14]；LIFT学习领先指标捕捉异步依赖[15]。但这些方法仍缺乏端到端的自适应学习能力。

**核心挑战**：如何设计可学习的CI/CD门控机制；如何基于元学习实现策略选择；如何利用因果发现自动识别变量间真实依赖。

### 4.2 深层非平稳性处理不足

**问题描述**：时序数据的分布随时间变化是普遍现象，但当前主流方法仅处理了浅层的均值-方差漂移[7][8]。RevIN通过可逆实例归一化消除实例间的分布差异，已成为多数模型的标准组件。然而，深层非平稳性（如趋势突变、周期性变化、概念漂移）尚未得到充分解决。

**现有尝试**：Non-stationary Transformer引入去平稳注意力机制[8]；2024-2025年出现了SAN（时间切片自适应归一化）、FAN（频域自适应归一化）、DDN（双域动态归一化）等精细化方法[7]，但仍是预设的处理模式。

**核心挑战**：如何将Stable Learning的因果视角系统性引入时序预测；如何设计能够在线检测和适应分布变化的机制；如何探索自监督学习提取分布不变表示。

### 4.3 超长序列建模效率瓶颈

**问题描述**：虽然PatchTST通过Patch设计将输入Token数量从L减少到约L/S，ModernTCN通过超大卷积核显著扩大有效感受野[1][11]，但在数万个时间步的超长序列场景下仍面临计算和内存挑战。

**现有尝试**：Mamba/SSM架构（如TimeMachine、LinOSS）提供了线性复杂度O(L)的解决方案，ICLR 2025发表的LinOSS在长序列任务上实现了Mamba两倍的性能[11]，但其在多变量场景下的有效性尚需进一步验证。

**核心挑战**：如何结合SSM与Transformer的混合架构；如何开发稀疏注意力的新变体；如何探索层次化序列建模策略。

### 4.4 扩散模型推理效率低下

**问题描述**：RATD等扩散模型方法在概率预测和不确定性估计方面表现突出，但多步迭代采样导致推理时间显著高于确定性预测方法，限制了实时应用[3][9]。

**效率对比**：

|方法类型|计算复杂度|精度水平|推理延迟|适用场景|
|---|---|---|---|---|
|线性模型|O(TN)|中等|极低|边缘部署|
|MLP/TCN|O(TN)|高|低|通用场景|
|Transformer|O((T/S)²N)|高|中|云端推理|
|扩散模型|O(T·步数)|最高|高|离线分析|
|SSM/Mamba|O(TN)|高|低|超长序列|

**现有尝试**：SimDiff简化扩散步骤实现极速点预测，S2DBM利用布朗桥减少随机性[3]，但与确定性模型相比仍有数量级的效率差距。

### 4.5 变量间因果关系建模不足

**问题描述**：现有方法主要建模变量间的统计相关性而非因果关系[3]。在存在虚假相关的场景下（如由共同混杂因素导致的伪相关），基于统计相关的预测可能失效。

**现有尝试**：Stable Learning提出的特征去相关思想为识别因果关系提供了启发，但该方法依赖多环境数据，在单一环境下难以区分稳定特征与不稳定特征。

**核心挑战**：如何将因果发现算法（如PC、FCI、Granger Causality）与时序预测系统性结合；如何利用干预数据学习因果结构；如何探索反事实推理在时序预测中的应用。

### 4.6 计算效率与精度权衡

**问题描述**：从O(T²N²)的全注意力到O(TN)的线性方法，效率提升显著，但精度上限仍有争议。如何在保证预测精度的前提下实现实时预测和边缘部署是持续挑战。

**核心挑战**：模型压缩与量化技术；动态计算分配（根据输入复杂度调整计算量）；硬件感知的架构搜索。

---

## 5. 创新研究设想

基于上述技术瓶颈分析和最新文献调研，本章提出五个具有创新潜力的研究方向。

### 5.1 自适应通道交互机制

#### 5.1.1 研究动机与目标

当前CI与CD策略的二元对立限制了模型在不同场景下的适应能力。理想的解决方案应能根据数据特性和任务需求自动调整变量交互程度，实现"该独立时独立，该交互时交互"的智能决策。核心研究目标是设计一种端到端可学习的自适应通道交互机制，能够在单一模型框架内动态平衡CI与CD策略的优势。

#### 5.1.2 技术路径

**路径一：门控动态选择机制**。通过可学习的门控权重实现策略的软切换，核心公式为：

$$Y = G \cdot f_{CD}(X) + (1-G) \cdot f_{CI}(X)$$

其中$G \in [0,1]^{C \times T}$是基于输入特征学习的权重矩阵。门控权重可通过以下方式计算：

$$G = \sigma(W_g \cdot [\text{ChannelSim}(X); \text{TemporalVar}(X)])$$

其中$\text{ChannelSim}$计算通道间相似度矩阵，$\text{TemporalVar}$计算时间维度的变异系数。

**路径二：维度反转与全局交互**。参考iTransformer的设计思想[4]，将Transformer的注意力机制作用于变量维度而非时间维度，从而在CI骨干上实现CD效果。

**路径三：图结构自适应学习**。利用动态图卷积网络，根据时序片段的相似度实时演化邻接矩阵$A_t$。

#### 5.1.3 相关文献支持

|论文|会议/年份|核心贡献|与本方向关联|
|---|---|---|---|
|iTransformer|ICLR 2024|变量Token化|维度反转思想|
|CGN|ICASSP 2024|通道门控单元|门控机制设计|
|CrossGNN|NeurIPS 2023|跨通道图交互|图结构学习|
|Channel Clustering|NeurIPS 2024|通道聚类策略|聚类思想借鉴|

#### 5.1.4 实验验证思路

**数据集选择**：Traffic（862变量，高维场景）、Weather（21变量，中等规模）、Solar-Energy（137变量，强相关场景）、ETTh1（7变量，弱相关场景）。

**评估指标**：MSE、MAE作为主要预测性能指标；门控权重分布分析验证自适应行为；消融实验量化各组件贡献。

**基线模型**：PatchTST（CI代表）、iTransformer（CD代表）、SOFTS（折中代表）、DLinear（简单基线）。

#### 5.1.5 预期成果与评估指标

- 在不同变量相关性强度的数据集上，相比固定策略方法MSE平均降低5-10%
- 门控权重可视化显示与变量相关性强度的正相关性
- 在分布漂移场景下保持稳定性能

### 5.2 因果时序预测

#### 5.2.1 研究动机与目标

相关性不等于因果性。在非平稳环境下，变量间的统计相关性会随时间改变，而因果结构通常保持稳定[3]。传统时序预测方法依赖数据中的统计规律，当测试分布与训练分布不一致时容易失效。核心研究目标是将因果发现与时序预测深度融合，构建在分布偏移下仍能保持稳定预测性能的模型。

#### 5.2.2 技术路径

**路径一：因果掩码注意力**。利用Granger因果检验或PC算法预先构建因果矩阵$M$，并将其作为掩码应用于Transformer的注意力层：

$$\text{Attn}(Q,K,V) = \text{Softmax}\left(\frac{QK^T}{\sqrt{d}} \odot M\right)V$$

其中$M_{ij} = 1$表示变量$j$对变量$i$存在因果影响。

**路径二：不变表示学习**。通过干预增强学习环境不变特征，将不同时段视为不同"域"，学习在所有环境中都稳定的特征表示。

**路径三：端到端因果发现与预测联合学习**。将因果图学习作为可微分模块嵌入预测网络，联合优化预测损失和因果发现损失。

#### 5.2.3 相关文献支持

|论文|会议/年份|核心贡献|与本方向关联|
|---|---|---|---|
|CausalTime|ICLR 2024|因果时序基准|评估标准|
|CausalFormer|IEEE 2023|因果掩码注意力|技术路径参考|
|CUTS|arXiv 2023|不规则时序因果发现|因果发现算法|
|StableNet|CVPR 2021|稳定学习框架|不变表示思想|

#### 5.2.4 实验验证思路

**数据集选择**：CausalTime合成数据集（具有已知因果图的ground truth）、PhysioNet医疗数据、Exchange金融数据。

**评估指标**：RMSE、MAE评估预测性能；SHD（Structural Hamming Distance）评估因果图发现准确性；分布偏移后的性能下降幅度评估鲁棒性。

#### 5.2.5 预期成果与评估指标

- 在CausalTime数据集上因果图发现SHD < 5
- 在人工分布偏移场景下，性能下降幅度比统计模型低30%以上
- 学习到的因果结构与领域知识一致

### 5.3 高效扩散模型

#### 5.3.1 研究动机与目标

扩散模型通过逆转噪声注入过程生成概率分布，能够输出完整的预测分布而非单一点预测[3][9]。然而，标准扩散模型需要数十到上百步迭代采样，推理时间比确定性模型高1-2个数量级。核心研究目标是在保持扩散模型概率建模优势的同时，将推理效率提升至实用水平。

#### 5.3.2 技术路径

**路径一：流匹配（Flow Matching）**。采用确定性的概率流路径：

$$x_t = (1-t)x_0 + tx_1$$

通过更直的采样轨迹，大幅减少采样步数（从100步降至5-10步）。

**路径二：多分辨率去噪**。采用季节性-趋势分解，实现"由易到难"的生成过程：首先在低分辨率下生成趋势成分，逐步细化高频季节性细节。

**路径三：一致性模型**。训练模型直接从任意噪声水平映射到数据分布，实现一步或少步生成。

**路径四：知识蒸馏加速**。将多步扩散模型作为教师，蒸馏出快速的学生模型。

#### 5.3.3 相关文献支持

|论文|会议/年份|核心贡献|加速效果|
|---|---|---|---|
|TSFlow|arXiv 2024|流匹配+高斯过程先验|采样步数减少90%|
|mr-Diff|ICLR 2024|多分辨率去噪|推理速度提升5倍|
|Consistency Models|ICLR 2025|一步生成|推理速度提升200倍|
|RATD|NeurIPS 2024|检索增强扩散|概率预测基线|

#### 5.3.4 实验验证思路

**数据集选择**：Electricity（需要不确定性估计）、Exchange-Rate（金融尾部风险）、Weather（概率气象预报）。

**评估指标**：CRPS评估概率预测质量；推理延迟（ms/样本）评估效率；MSE/MAE评估点预测性能。

#### 5.3.5 预期成果与评估指标

- CRPS保持与标准扩散模型同等水平（差异<5%）
- 推理速度提升50-200倍
- 在需要不确定性估计的实际应用场景中端到端效果验证

### 5.4 分布外泛化与非平稳性建模

#### 5.4.1 研究动机与目标

现实世界的时序数据具有强烈的非平稳性，表现为均值、方差、趋势、周期的动态漂移[7][8]。传统的离线训练模型难以应对测试阶段出现的"新常态"。核心研究目标是设计能够在线检测和适应分布变化的机制，实现"训练一次，持续适应"的在线学习能力。

#### 5.4.2 技术路径

**路径一：测试时适应（Test-Time Adaptation, TTA）**。在推理阶段利用当前观测到的窗口数据，通过最小化自监督损失在线更新模型参数：

$$\theta_{t+1} = \theta_t - \eta \nabla_\theta \mathcal{L}_{SSL}(x_t; \theta_t)$$

其中$\mathcal{L}_{SSL}$可以是掩码重建损失、对比学习损失等不依赖标签的自监督目标。

**路径二：自监督分布不变表示学习**。通过预训练学习跨时段、跨分布的不变表示，利用域自适应技术学习域不变特征。

**路径三：动态归一化机制**。扩展RevIN为多域动态归一化：时域归一化处理均值-方差漂移，频域归一化处理周期性变化（如FAN[7]）。

**路径四：因果视角的稳定预测**。将Stable Learning的理论框架系统性引入时序预测，识别并利用稳定特征。

#### 5.4.3 相关文献支持

|论文|会议/年份|核心贡献|与本方向关联|
|---|---|---|---|
|TAFAS|AAAI 2025|测试时适应框架|TTA技术路径|
|TimeDRL|IEEE 2024|解耦表示学习|不变表示思想|
|Dish-TS|AAAI 2023|分布偏移范式|分布对齐方法|
|FAN|NeurIPS 2024|频域自适应归一化|多域归一化|

#### 5.4.4 实验验证思路

**数据集选择**：ETTh1/ETTm2（存在明显概念漂移）、金融数据（存在regime shift）、合成数据（可控的分布偏移场景）。

**评估指标**：Online MSE（逐窗口更新的在线预测误差）；适应速度（达到稳定性能所需样本数）；分布偏移前后的性能下降幅度。

#### 5.4.5 预期成果与评估指标

- 在人工构造的分布偏移场景下，性能下降幅度比无适应基线低50%以上
- 适应速度：在100个样本内达到稳定性能
- TTA更新不导致灾难性遗忘

### 5.5 SSM-Transformer混合架构

#### 5.5.1 研究动机与目标

Transformer的二次复杂度O(L²)限制了其在超长序列中的应用，而Mamba等选择性状态空间模型虽提供了线性复杂度O(L)，但对复杂语义的建模能力略逊[11]。混合架构旨在结合两者的长处。核心研究目标是设计计算效率与建模能力兼优的混合架构，在超长序列场景下实现SOTA性能。

#### 5.5.2 技术路径

**路径一：多尺度Mamba集成**。利用四个Mamba块分别处理不同尺度的上下文：

$$H = \text{Concat}[\text{Mamba}_1(X_{s_1}), \text{Mamba}_2(X_{s_2}), \text{Mamba}_3(X_{s_3}), \text{Mamba}_4(X_{s_4})]$$

其中$X_{s_i}$表示第$i$个尺度的输入。

**路径二：交替堆叠架构**。在每7层Mamba后插入1层Transformer，用于修正SSM的长期记忆衰减，提供全局信息交互的"检查点"。

**路径三：LinOSS振荡状态空间**。采用ICLR 2025提出的线性振荡状态空间模型，引入振荡项建模周期性模式。

**路径四：时间-变量双轴混合**。时间轴使用SSM建模长程依赖（线性复杂度），变量轴使用Transformer建模跨变量关系（O(N²)但N通常较小）。

#### 5.5.3 相关文献支持

|论文|会议/年份|核心贡献|效率提升|
|---|---|---|---|
|TimeMachine|ECAI 2024|四重Mamba集成|显存降低80%|
|LinOSS|ICLR 2025|线性振荡SSM|性能达Mamba 2倍|
|Jamba|AI21 2024|Transformer-Mamba混合|上下文长度256K|
|MambaTS|arXiv 2024|时序Mamba适配|线性复杂度|

#### 5.5.4 实验验证思路

**数据集选择**：Traffic（超长序列，862变量）、PEMS04（交通预测，复杂时空依赖）、ETTh1/ETTm1（标准基准对照）。

**评估指标**：Memory Usage（GPU显存占用）、MSE/MAE（预测性能）、Inference Throughput（吞吐量）、Training Time（训练时间）。

#### 5.5.5 预期成果与评估指标

- 在超长序列（>10000步）场景下，显存占用降低70%以上
- 预测性能与纯Transformer持平或更优
- 推理吞吐量提升3-5倍

---

## 6. 研究路线图与优先级建议

### 6.1 创新方向优先级评估矩阵

本节从创新性、可行性、影响力三个维度对五个创新方向进行综合评估。

|研究方向|创新性|可行性|影响力|综合评分|推荐优先级|
|---|---|---|---|---|---|
|自适应CI/CD机制|★★★★☆|★★★★★|★★★★★|4.7|**1**|
|OOD泛化与非平稳性|★★★★☆|★★★★☆|★★★★★|4.3|**2**|
|因果时序预测|★★★★★|★★★☆☆|★★★★☆|4.0|3|
|高效扩散模型|★★★★☆|★★★★☆|★★★★☆|4.0|3|
|SSM-Transformer混合|★★★☆☆|★★★★★|★★★★☆|4.0|3|

**第一优先级：自适应通道交互机制**

推荐理由：(1) CI vs CD是当前领域最核心的未解争议，解决这一问题具有里程碑意义；(2) 技术路径清晰，门控机制、维度反转、图结构学习均有成熟工具支持；(3) 可在现有模型基础上进行模块化改进，验证周期短；(4) 对各类数据集和应用场景具有普适价值。

**第二优先级：OOD泛化与非平稳性建模**

推荐理由：(1) 非平稳性是时序数据的本质特征，现有方法处理不足；(2) TTA技术在其他领域已有成熟实践，迁移至时序领域可行性高；(3) 直接关联实际部署场景的鲁棒性需求，工业界关注度高；(4) 可与其他创新方向（如因果学习）形成协同。

**第三优先级（并列）**

因果时序预测理论深度高但验证难度大；高效扩散模型对实时应用价值大但技术门槛较高；SSM-Transformer混合架构创新性相对较低但工程可行性最强。可根据研究团队的技术积累和资源情况选择性开展。

### 6.2 分阶段研究建议

#### 6.2.1 阶段一（0-6个月）：自适应CI/CD机制

|月份|任务|产出|
|---|---|---|
|月1-2|门控机制原型开发与基准测试|代码框架、初步实验结果|
|月3-4|图结构自适应学习模块实现|改进版模型、对比实验|
|月5-6|综合实验与论文撰写|技术报告、论文初稿|

**关键里程碑**：
- 月2末：门控机制在ETTh1上MSE优于PatchTST
- 月4末：图结构模块在Traffic上超越SOFTS
- 月6末：论文投稿NeurIPS/ICML

#### 6.2.2 阶段二（6-12个月）：OOD泛化与非平稳性

|月份|任务|产出|
|---|---|---|
|月7-8|TTA框架设计与自监督任务选择|TTA原型、任务对比分析|
|月9-10|多域动态归一化机制开发|归一化模块、消融实验|
|月11-12|在线学习系统集成与评估|完整系统、部署文档|

**关键里程碑**：
- 月8末：TTA框架在合成分布偏移数据上验证有效
- 月10末：多域归一化在FAN基础上进一步提升
- 月12末：系统级解决方案发布

#### 6.2.3 阶段三（12-18个月）：选择性深入

根据前两阶段的研究进展和资源情况，选择以下路线之一深入：

**路线A：因果时序预测（理论导向）**
- 因果图学习可微分化
- CausalTime基准全面评测
- 理论分析与收敛保证

**路线B：高效扩散模型（应用导向）**
- 流匹配在时序场景适配
- 一致性模型训练策略
- 实际部署与效率验证

**路线C：SSM-Transformer混合（效率导向）**
- LinOSS多变量扩展
- 混合比例自动搜索
- 超长序列基准建立

### 6.3 资源配置与合作建议

**计算资源需求**：

|研究方向|GPU需求|训练时长|数据存储|
|---|---|---|---|
|自适应CI/CD|4×A100|2-3天/实验|100GB|
|OOD泛化|2×A100|1-2天/实验|50GB|
|因果预测|4×A100|3-5天/实验|100GB|
|高效扩散|8×A100|5-7天/实验|200GB|
|SSM混合|4×A100|2-4天/实验|100GB|

**合作建议**：
1. **学术合作**：与因果推断、概率机器学习领域团队建立合作，引入理论支撑
2. **产业合作**：与能源、金融、交通领域企业合作，获取真实数据和应用反馈
3. **开源社区**：积极参与Time Series Library等开源项目，提升影响力

---

## 7. 参考文献

[1] AAAI, 2023-02-07. Are Transformers Effective for Time Series Forecasting?. https://arxiv.org/abs/2208.05233

[2] NeurIPS, 2024-12-10. SOFTS: Efficient Multivariate Time Series Forecasting with Series-Core Fusion. https://neurips.cc/virtual/2024/poster/93845

[3] arXiv, 2024-01-05. The rise of diffusion models in time-series forecasting. https://arxiv.org/abs/2401.03006

[4] ICLR, 2024-05-01. iTransformer: Inverted Transformers Are Effective for Time Series Forecasting. https://openreview.net/forum?id=oVpf9S2K57

[5] NeurIPS, 2021-12-06. Autoformer: Decomposition Transformers with Auto-Correlation for Long-Term Series Forecasting. https://huggingface.co/docs/transformers/model_doc/autoformer

[6] Amazon Science, 2024-03-12. Chronos: Learning the Language of Time Series. https://arxiv.org/abs/2403.07815

[7] NeurIPS, 2024-12-10. Frequency adaptive normalization for non-stationary time series forecasting. https://proceedings.neurips.cc/paper_files/paper/2024/hash/37c6d0bc4d2917dcbea693b18504bd87-Abstract-Conference.html

[8] NeurIPS, 2022-11-28. Non-stationary transformers: Exploring the stationarity in time series forecasting. https://proceedings.neurips.cc/paper_files/paper/2022/hash/4054556fcaa934b0bf76da52cf4f92cb-Abstract-Conference.html

[9] NeurIPS, 2024-12-10. Retrieval-Augmented Diffusion Models for Time Series Forecasting. https://neurips.cc/virtual/2024/poster/93845

[10] NeurIPS, 2022-11-28. SCINet: Time series modeling and forecasting with sample convolution and interaction. https://proceedings.neurips.cc/paper_files/paper/2022/hash/266983d0949aed78a16fa4782237dea7-Abstract-Conference.html

[11] ICLR, 2024-05-01. ModernTCN: A Modern Pure Convolution Structure for General Time Series Analysis. https://openreview.net/forum?id=vp9vV9gh95

[12] ICLR, 2024-05-01. Time-LLM: Time Series Forecasting by Reprogramming Large Language Models. https://iclr.cc/virtual/2024/poster/18161

[13] IEEE TKDE, 2024. The capacity and robustness trade-off: Revisiting the channel independent strategy for multivariate time series forecasting. https://ieeexplore.ieee.org/abstract/document/10529618/

[14] NeurIPS, 2024. From similarity to superiority: Channel clustering for time series forecasting. https://proceedings.neurips.cc/paper_files/paper/2024/hash/eb9b18ccb76a1156af5779ffdca1d91f-Abstract-Conference.html

[15] arXiv, 2024-01. Rethinking channel dependence for multivariate time series forecasting: Learning from leading indicators. https://arxiv.org/abs/2401.17548

[16] IEEE, 2023-12. CausalFormer: Causal discovery-based transformer for multivariate time series forecasting. https://ieeexplore.ieee.org/abstract/document/10373365/

[17] ICLR, 2024-05. mr-Diff: Multi-resolution Diffusion Model for Time Series Forecasting. https://iclr.cc/virtual/2024/poster/18144

[18] arXiv, 2024-03. TimeMachine: A Time Series is Worth 4 Mambas for Long-term Forecasting. https://arxiv.org/abs/2403.09898

[19] ICLR, 2025-01. Linear Oscillatory State-Space Models (LinOSS). https://openreview.net/forum?id=Ai8Hw3AXqks

[20] ICLR, 2024-05. CausalTime: Realistically generated time-series for benchmarking of causal discovery. https://proceedings.iclr.cc/paper_files/paper/2024/hash/0c79d6ed1788653643a1ac67b6ea32a7-Abstract-Conference.html

[21] AAAI, 2023. Dish-TS: A general paradigm for alleviating distribution shift in time series forecasting. https://ojs.aaai.org/index.php/AAAI/article/view/25914

[22] AAAI, 2025-02. Battling the non-stationarity in time series forecasting via test-time adaptation (TAFAS). https://ojs.aaai.org/index.php/AAAI/article/view/33965

[23] Salesforce AI Research, 2024-10-15. Moirai 2.0: Next-Gen Time Series Foundation Model. https://arxiv.org/abs/2410.15616

[24] arXiv, 2024-10. Flow Matching with Gaussian Process Priors for Probabilistic Time Series Forecasting (TSFlow). https://arxiv.org/abs/2410.03024

[25] ICLR, 2025-01. Consistency models made easy. https://proceedings.iclr.cc/paper_files/paper/2025/hash/bb166dd4de5dba363bf1023eb956a826-Abstract-Conference.html

[26] IEEE, 2024-06. Timedrl: Disentangled representation learning for multivariate time-series. https://ieeexplore.ieee.org/abstract/document/10597874/

[27] IEEE ICASSP, 2024-03. CGN: A simple yet effective multi-channel gated network for long-term time series forecasting. https://ieeexplore.ieee.org/abstract/document/10448209/

[28] AI21 Labs, 2024-08. Jamba 1.5 Technical Report. https://arxiv.org/abs/2408.12570

[29] Expert Systems with Applications, 2024-01. Dynamic multi-fusion spatio-temporal graph neural network for multivariate time series forecasting. https://www.sciencedirect.com/science/article/pii/S0957417423032311

[30] Nature Reviews Earth & Environment, 2023-04. Causal inference for time series. https://www.nature.com/articles/s43017-023-00431-y